package com.hospital.app.service;

import java.util.List;

import com.hospital.app.entity.Paciente;

public interface IPacientesService {
	List<Paciente> getAllPacientes();
	   
    Paciente savePaciente(Paciente paciente);
    
    Paciente findById(int id);
    
}
