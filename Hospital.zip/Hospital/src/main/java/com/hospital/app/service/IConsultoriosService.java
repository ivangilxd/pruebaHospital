package com.hospital.app.service;

import java.util.List;

import com.hospital.app.entity.Consultorio;

public interface IConsultoriosService {
	List<Consultorio> getAllConsultorios();
	   
    Consultorio saveConsultorio(Consultorio consultorio);
    
    Consultorio getById(int id);
}
