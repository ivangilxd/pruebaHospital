package com.hospital.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.app.entity.Cita;
import com.hospital.app.entity.CitaVo;
import com.hospital.app.repository.ICitasRepository;

@Service
public class CitasService implements ICitasService{
	@Autowired
    private ICitasRepository citasRepository;

	@Override
	public List<CitaVo> getAllCitas() {
		List<CitaVo> lista=new ArrayList<>();
        List<Cita> listaBD=new ArrayList<>();
        listaBD=citasRepository.findAll();
        if (!listaBD.isEmpty()) {
            for (Cita citasEntity : listaBD) {
                CitaVo citas=new CitaVo();
                citas.setId_cita(citasEntity.getId());
                citas.setFecha_inicio(citasEntity.getFecha_inicio());
                citas.setFecha_fin(citasEntity.getFecha_fin());
                citas.setMedico(citasEntity.getMedico().getId());
                citas.setPaciente(citasEntity.getPaciente().getId());
                citas.setConsultorio(citasEntity.getConsultorio().getId());
                lista.add(citas);
            }
        }
        return lista;
	}

	@Override
	public List<Cita> getAllCitasBD() {
		return citasRepository.findAll();
	}

	@Override
	public Cita saveCitas(Cita citas) {
		return citasRepository.save(citas);
	}

	@Override
	public void deleteCita(Integer id) {
		citasRepository.deleteById(id);
		
	}

}
