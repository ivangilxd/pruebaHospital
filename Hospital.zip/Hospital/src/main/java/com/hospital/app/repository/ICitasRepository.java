package com.hospital.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospital.app.entity.Cita;

import jakarta.transaction.Transactional;

@Transactional
@Repository
public interface ICitasRepository extends JpaRepository<Cita, Integer> {

}
