package com.hospital.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.app.entity.Paciente;
import com.hospital.app.repository.IPacientesRepository;

@Service
public class PacienteService implements IPacientesService{
	@Autowired
    private IPacientesRepository pacienteRepository;
	

	@Override
	public List<Paciente> getAllPacientes() {
		return pacienteRepository.findAll();
	}

	@Override
	public Paciente savePaciente(Paciente paciente) {
		return pacienteRepository.save(paciente);
	}

	@Override
	public Paciente findById(int id) {
		return pacienteRepository.findById(id);
	}
	
}
