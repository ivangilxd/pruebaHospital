package com.hospital.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.app.entity.Consultorio;
import com.hospital.app.repository.IConsultorioRepository;

@Service
public class ConsultorioService implements IConsultoriosService{
	@Autowired
    private IConsultorioRepository consultorioRepository;

	@Override
	public List<Consultorio> getAllConsultorios() {
		return consultorioRepository.findAll();
	}

	@Override
	public Consultorio saveConsultorio(Consultorio consultorio) {
		return consultorioRepository.save(consultorio);
	}

	@Override
	public Consultorio getById(int id) {
		return consultorioRepository.findById(id);
	}

}
