package com.hospital.app.service;

import java.util.List;

import com.hospital.app.entity.Cita;
import com.hospital.app.entity.CitaVo;

public interface ICitasService {
	List<CitaVo> getAllCitas();
    
    List<Cita> getAllCitasBD ();
    
    Cita saveCitas(Cita citas);
    
    void deleteCita(Integer id);
}
