package com.hospital.app.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name="medicos")
public class Medico  implements Serializable{
	  	@Id
	  	@GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id_medico")
	    public Integer id;
	    
	    @Column(name="nombres")
	    public String nombres;

	    @Column(name="apellidoP")
	    public String apellidoP;
	    
	    @Column(name="apellidoM")
	    public String apellidoM;
	    
	    @Column(name="especialidad")
	    public String especialidad;

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getNombres() {
			return nombres;
		}

		public void setNombres(String nombres) {
			this.nombres = nombres;
		}

		public String getApellidoP() {
			return apellidoP;
		}

		public void setApellidoP(String apellidoP) {
			this.apellidoP = apellidoP;
		}

		public String getApellidoM() {
			return apellidoM;
		}

		public void setApellidoM(String apellidoM) {
			this.apellidoM = apellidoM;
		}

		public String getEspecialidad() {
			return especialidad;
		}

		public void setEspecialidad(String especialidad) {
			this.especialidad = especialidad;
		}
	    
	    
}
