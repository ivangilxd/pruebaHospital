package com.hospital.app.service;

import java.util.List;

import com.hospital.app.entity.Medico;

public interface IMedicosService {
	 	List<Medico> getAllMedicos();
	   
	    Medico saveMedico(Medico medico);
	    
	    Medico getById(int id);
}
