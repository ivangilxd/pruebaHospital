package com.hospital.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.app.entity.Cita;
import com.hospital.app.entity.CitaVo;
import com.hospital.app.entity.Consultorio;
import com.hospital.app.entity.Medico;
import com.hospital.app.entity.Paciente;
import com.hospital.app.service.CitasService;
import com.hospital.app.service.ConsultorioService;
import com.hospital.app.service.MedicoService;
import com.hospital.app.service.PacienteService;

@RestController
public class ServiciosController {
	@Autowired
    private CitasService citasService;

    @Autowired
    private PacienteService pacientesService;

    @Autowired
    private MedicoService medicosService;
    
    @Autowired
    private ConsultorioService consultoriosService;
    
    
    @GetMapping("/api/medicos")
    public ResponseEntity<Object> listMedicos() {
        return new ResponseEntity<>(medicosService.getAllMedicos(), HttpStatus.OK);
    }

    @PostMapping("/api/medicos")
    public ResponseEntity<Object> saveMedicos(@RequestBody Medico medico) {
        medicosService.saveMedico(medico);
        return new ResponseEntity<>(medicosService.getAllMedicos(), HttpStatus.OK);
    }
    
    @GetMapping("/api/pacientes")
    public ResponseEntity<Object> listPacientes() {
        return new ResponseEntity<>(pacientesService.getAllPacientes(), HttpStatus.OK);
    }
    @PostMapping("/api/pacientes")
    public ResponseEntity<Object> savePacientes(@RequestBody Paciente paciente) {
        pacientesService.savePaciente(paciente);
        return new ResponseEntity<>(pacientesService.getAllPacientes(), HttpStatus.OK);
    }
    
    @GetMapping("/api/consultorios")
    public ResponseEntity<Object> listConsultorios() {
        return new ResponseEntity<>(consultoriosService.getAllConsultorios(), HttpStatus.OK);
    }
    @PostMapping("/api/consultorios")
    public ResponseEntity<Object> saveConsultorios(@RequestBody Consultorio consultorio) {
    	consultoriosService.saveConsultorio(consultorio);
        return new ResponseEntity<>(consultoriosService.getAllConsultorios(), HttpStatus.OK);
    }
    
    @GetMapping("/api/citas")
    public ResponseEntity<Object> listCitas() {
        return new ResponseEntity<>(citasService.getAllCitasBD(), HttpStatus.OK);
    }
    @PostMapping("/api/citas")
    public ResponseEntity<Object> saveCitas(@RequestBody CitaVo citasEntity) {
        Paciente paciente = new Paciente();
        paciente=pacientesService.findById(citasEntity.getPaciente());
        Medico medico =new  Medico();
        medico=medicosService.getById(citasEntity.getMedico());
        Consultorio consultorio = new Consultorio();
        consultorio=consultoriosService.getById(citasEntity.getConsultorio());
        if (paciente==null || medico==null) {
            return new ResponseEntity<>("Paciente o Medico vacios", HttpStatus.BAD_REQUEST);
        }
        Cita citaSav = new Cita();
        citaSav.setFecha_inicio(citasEntity.getFecha_inicio());
        citaSav.setFecha_fin(citasEntity.getFecha_fin());
        citaSav.setMedico(medico);
        citaSav.setPaciente(paciente);
        citaSav.setConsultorio(consultorio);
        citasService.saveCitas(citaSav);
        return new ResponseEntity<>(citasService.getAllCitas(), HttpStatus.OK);
    }
    @DeleteMapping("api/citas/{id}")
	public ResponseEntity<?> delete(@PathVariable(value ="id") Integer userid){
    	citasService.deleteCita(userid);
    	return new ResponseEntity<>(citasService.getAllCitas(), HttpStatus.OK);
	}

    
}
