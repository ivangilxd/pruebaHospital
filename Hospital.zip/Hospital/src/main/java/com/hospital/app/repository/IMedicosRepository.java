package com.hospital.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital.app.entity.*;

import jakarta.transaction.Transactional;

@Transactional
@Repository
public interface IMedicosRepository extends JpaRepository<Medico, Integer>{
	Medico findById(int idMedico);
}
