package com.hospital.app.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="citas")
public class Cita implements Serializable {
	@Id
  	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cita")
    public Integer id;
	
	@Column(name="fecha_inicio")
    private Date fecha_inicio;
	
	@Column(name="fecha_fin")
    private Date fecha_fin;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_medico", referencedColumnName = "id_medico")
    public Medico medico;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_consultorio", referencedColumnName = "id_consultorio")
    public Consultorio consultorio;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_paciente", referencedColumnName = "id_paciente")
    public Paciente paciente;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getFecha_inicio() {
		return fecha_inicio;
	}

	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}

	public Date getFecha_fin() {
		return fecha_fin;
	}

	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public Consultorio getConsultorio() {
		return consultorio;
	}

	public void setConsultorio(Consultorio consultorio) {
		this.consultorio = consultorio;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
	
}
