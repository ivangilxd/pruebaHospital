package com.hospital.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospital.app.entity.Paciente;

import jakarta.transaction.Transactional;

@Transactional
@Repository
public interface IPacientesRepository extends JpaRepository<Paciente, Integer>{
	Paciente findById(int id_paciente);
}
