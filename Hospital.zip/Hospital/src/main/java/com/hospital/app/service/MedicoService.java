package com.hospital.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hospital.app.entity.Medico;
import com.hospital.app.repository.IMedicosRepository;

@Service
public class MedicoService implements IMedicosService{
	
	public MedicoService(IMedicosRepository courseRepository) {
        this.medicosRepository = courseRepository;
    }

	private IMedicosRepository medicosRepository;
	@Override
	public List<Medico> getAllMedicos() {
		return medicosRepository.findAll();
	}

	@Override
	public Medico saveMedico(Medico medico) {
		return medicosRepository.save(medico);
	}

	@Override
	public Medico getById(int id) {
		return medicosRepository.findById(id);
	}

}
